const API_URL = "/api/tasks";

// DOM Elements
const taskForm = document.getElementById("taskForm");
const formTitle = document.getElementById("formTitle");
const taskIdInput = document.getElementById("taskId");
const titleInput = document.getElementById("title");
const descriptionInput = document.getElementById("description");
const completedInput = document.getElementById("completed");
const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");
const taskList = document.getElementById("taskList");
const loadingEl = document.getElementById("loading");
const emptyMessageEl = document.getElementById("emptyMessage");
const filterBtns = document.querySelectorAll(".filter-btn");

let tasks = [];
let currentFilter = "all";

// Fetch and load tasks on page load
document.addEventListener("DOMContentLoaded", () => {
  fetchTasks();
  setupEventListeners();
});

// Setup Events
function setupEventListeners() {
  taskForm.addEventListener("submit", handleFormSubmit);
  cancelBtn.addEventListener("click", resetForm);

  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentFilter = btn.dataset.filter;
      renderTasks();
    });
  });
}

// 1. READ: Fetch all tasks
async function fetchTasks() {
  loadingEl.style.display = "block";
  emptyMessageEl.style.display = "none";
  taskList.innerHTML = "";

  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error("Failed to load tasks");
    tasks = await res.json();
    renderTasks();
  } catch (err) {
    alert("Error loading tasks: " + err.message);
  } finally {
    loadingEl.style.display = "none";
  }
}

// 2. CREATE or UPDATE task
async function handleFormSubmit(e) {
  e.preventDefault();

  const id = taskIdInput.value;
  const taskData = {
    title: titleInput.value.trim(),
    description: descriptionInput.value.trim(),
    completed: completedInput.checked
  };

  if (!taskData.title) {
    alert("Title is required");
    return;
  }

  try {
    if (id) {
      // UPDATE (PUT)
      const res = await fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskData)
      });
      if (!res.ok) throw new Error("Failed to update task");
      const updated = await res.json();
      tasks = tasks.map((t) => (t._id === id ? updated : t));
    } else {
      // CREATE (POST)
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskData)
      });
      if (!res.ok) throw new Error("Failed to create task");
      const created = await res.json();
      tasks.unshift(created);
    }

    resetForm();
    renderTasks();
  } catch (err) {
    alert("Error: " + err.message);
  }
}

// 3. DELETE task
async function deleteTask(id) {
  if (!confirm("Are you sure you want to delete this task?")) return;

  try {
    const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to delete task");

    tasks = tasks.filter((t) => t._id !== id);
    renderTasks();

    // If editing the deleted task, reset the form
    if (taskIdInput.value === id) {
      resetForm();
    }
  } catch (err) {
    alert("Error: " + err.message);
  }
}

// 4. Toggle Completed status
async function toggleTask(id, completed) {
  try {
    const res = await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completed })
    });
    if (!res.ok) throw new Error("Failed to update task status");

    const updated = await res.json();
    tasks = tasks.map((t) => (t._id === id ? updated : t));
    renderTasks();
  } catch (err) {
    alert("Error: " + err.message);
    fetchTasks(); // reload on error
  }
}

// Populate form for Editing
function startEditTask(id) {
  const task = tasks.find((t) => t._id === id);
  if (!task) return;

  taskIdInput.value = task._id;
  titleInput.value = task.title;
  descriptionInput.value = task.description || "";
  completedInput.checked = Boolean(task.completed);

  formTitle.textContent = "Edit Task";
  submitBtn.textContent = "Update Task";
  cancelBtn.style.display = "inline-block";

  titleInput.focus();
}

// Reset form to Add mode
function resetForm() {
  taskIdInput.value = "";
  taskForm.reset();
  formTitle.textContent = "Add New Task";
  submitBtn.textContent = "Add Task";
  cancelBtn.style.display = "none";
}

// Render Tasks to DOM
function renderTasks() {
  taskList.innerHTML = "";

  const filtered = tasks.filter((task) => {
    if (currentFilter === "pending") return !task.completed;
    if (currentFilter === "completed") return task.completed;
    return true;
  });

  if (filtered.length === 0) {
    emptyMessageEl.style.display = "block";
    return;
  }

  emptyMessageEl.style.display = "none";

  filtered.forEach((task) => {
    const item = document.createElement("div");
    item.className = `task-item ${task.completed ? "is-completed" : ""}`;

    item.innerHTML = `
      <div class="task-left">
        <input 
          type="checkbox" 
          ${task.completed ? "checked" : ""} 
          aria-label="Toggle task completion"
          data-id="${task._id}"
        >
        <div class="task-details">
          <div class="task-title">${escapeHtml(task.title)}</div>
          ${task.description ? `<div class="task-desc">${escapeHtml(task.description)}</div>` : ""}
        </div>
      </div>
      <div class="task-actions">
        <button type="button" class="edit-btn" data-id="${task._id}">Edit</button>
        <button type="button" class="delete-btn" data-id="${task._id}">Delete</button>
      </div>
    `;

    // Event listeners for checkbox, edit, and delete
    const checkbox = item.querySelector('input[type="checkbox"]');
    checkbox.addEventListener("change", (e) => toggleTask(task._id, e.target.checked));

    const editBtn = item.querySelector(".edit-btn");
    editBtn.addEventListener("click", () => startEditTask(task._id));

    const deleteBtn = item.querySelector(".delete-btn");
    deleteBtn.addEventListener("click", () => deleteTask(task._id));

    taskList.appendChild(item);
  });
}

// Helper to escape HTML characters
function escapeHtml(text) {
  if (!text) return "";
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
